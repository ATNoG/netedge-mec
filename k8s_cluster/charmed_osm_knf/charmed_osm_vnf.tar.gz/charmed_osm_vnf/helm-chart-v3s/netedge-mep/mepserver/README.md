### Files for container image creation
