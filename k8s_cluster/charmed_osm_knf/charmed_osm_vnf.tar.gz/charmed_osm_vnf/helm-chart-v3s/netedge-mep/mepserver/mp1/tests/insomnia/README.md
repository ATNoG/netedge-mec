NetEdge.json is an Insomnia File that has the current endpoints and a dummy validation at the moment.
