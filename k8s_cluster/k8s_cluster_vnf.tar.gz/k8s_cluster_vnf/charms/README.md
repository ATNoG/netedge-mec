# charmed-kubernetes
Charmed Kubernetes cluster to use in VNFs
