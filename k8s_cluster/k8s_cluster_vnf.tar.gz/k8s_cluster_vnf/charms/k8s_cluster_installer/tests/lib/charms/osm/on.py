class OnMock:
   def config_changed():
      pass
   def install():
      pass
   def start():
      pass
   def configure_remote_action():
      pass
   def start_service_action():
      pass
   def deploy_k8s_controller_action():
      pass
   
   def deploy_k8s_workers_action():
      pass
   
   def get_k8s_controller_info_action():
      pass
   
   def join_k8s_workers_action():
      pass
   
   def remove_k8s_worker_action():
      pass
   
   def start_action():
      pass
   
   def stop_action():
      pass
   
   def restart_action():
      pass
   
   def reboot_action():
      pass
   
   def upgrade_action():
      pass
